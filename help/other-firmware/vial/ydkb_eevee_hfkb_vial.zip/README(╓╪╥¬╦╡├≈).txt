因为Flash空间不够，
为了支持 combos 和 tap dance，此固件目前禁用了ACTION_ONESHOT。

自行设置好按键后，建议保存一下，方便日后更新固件后，再导入恢复。
压缩包里提供了US默认按键设置供导入vial参考。