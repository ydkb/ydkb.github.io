因为Flash空间不够，所以未加入默认的keymap。
为了支持 combos 和 tap dance，此固件目前禁用了ACTION_ONESHOT。

请刷新固件后，从vial菜单里，导入keymap，压缩包里提供了一个默认的供参考。

自行设置好按键后，也建议保存一下，方便日后更新固件后，再导入恢复。