友情提醒：刷新固件前记得备份当前的按键设置。
Friendly Reminder: Remember to back up your current key settings before updating the firmware.